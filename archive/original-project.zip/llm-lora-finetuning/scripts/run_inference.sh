#!/usr/bin/env bash
# Run inference with a trained LoRA adapter.
# Usage: bash scripts/run_inference.sh --base_model <model> --adapter_dir <dir> --context "..." --question "..."
set -euo pipefail

cd "$(dirname "$0")/.."

python src/inference.py "$@"
