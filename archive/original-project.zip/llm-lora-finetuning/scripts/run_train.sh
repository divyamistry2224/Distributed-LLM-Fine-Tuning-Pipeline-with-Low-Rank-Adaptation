#!/usr/bin/env bash
# Launch LoRA fine-tuning across all configured GPUs.
set -euo pipefail

cd "$(dirname "$0")/.."

accelerate launch --config_file configs/accelerate_config.yaml src/train.py \
    --base_model "${BASE_MODEL:-meta-llama/Llama-2-7b-hf}" \
    --train_file "${TRAIN_FILE:-examples/sample_data.jsonl}" \
    --output_dir "${OUTPUT_DIR:-checkpoints/lora-doc-qa}" \
    --lora_config configs/lora_config.yaml \
    --num_train_epochs "${EPOCHS:-3}" \
    --per_device_train_batch_size "${BATCH_SIZE:-2}" \
    --gradient_accumulation_steps "${GRAD_ACCUM:-8}" \
    --learning_rate "${LR:-2e-4}"
