"""
End-to-end smoke test for the LoRA fine-tuning pipeline — runs entirely
offline, on CPU, in seconds, using a tiny randomly-initialized GPT-2-architecture
model (no download, no GPU, no Hugging Face Hub access required).

Purpose: prove that data loading, tokenization, LoRA attachment, the training
loop, checkpoint saving, and inference all work end-to-end with zero errors,
without needing the real 7B base model or a GPU. Swap in a real base model
name + configs/lora_config.yaml (see README) to run the production pipeline.

Usage:
    python scripts/smoke_test.py
"""

import os
import shutil
import sys
import tempfile

import torch
from tokenizers import ByteLevelBPETokenizer
from torch.utils.data import DataLoader
from transformers import GPT2Config, GPT2LMHeadModel, PreTrainedTokenizerFast

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from peft import PeftModel

from data import DataCollatorForCausalDocQA, load_document_qa_dataset
from model import attach_lora


def build_tiny_tokenizer(corpus_path: str, save_dir: str) -> PreTrainedTokenizerFast:
    """Train a tiny byte-level BPE tokenizer from scratch on the sample corpus.
    Fully offline — no pretrained vocab is downloaded."""
    raw_txt_path = os.path.join(save_dir, "corpus.txt")
    import json

    with open(corpus_path) as f_in, open(raw_txt_path, "w") as f_out:
        for line in f_in:
            rec = json.loads(line)
            f_out.write(rec["context"] + " " + rec["question"] + " " + rec["answer"] + "\n")

    tok = ByteLevelBPETokenizer()
    tok.train(files=[raw_txt_path], vocab_size=1000, min_frequency=1,
               special_tokens=["<pad>", "<s>", "</s>", "<unk>"])
    tok.save_model(save_dir)

    # Wrap the trained tokenizers-library backend directly as a fast HF tokenizer
    # (no pretrained checkpoint involved, no sentencepiece/tiktoken needed).
    # NOTE: `tok` here is the legacy `tokenizers.implementations` convenience
    # wrapper; transformers needs the underlying raw `tokenizers.Tokenizer`
    # object (`tok._tokenizer`), not the wrapper itself.
    fast_tok = PreTrainedTokenizerFast(tokenizer_object=tok._tokenizer, model_max_length=256)
    fast_tok.add_special_tokens({"pad_token": "<pad>"})
    return fast_tok


def build_tiny_model(vocab_size: int) -> GPT2LMHeadModel:
    """A randomly-initialized, deliberately tiny GPT-2-architecture model —
    a stand-in for the real 7B base model, used only to validate that the
    pipeline's mechanics (forward/backward pass, LoRA adapters, generation)
    are wired correctly."""
    config = GPT2Config(
        vocab_size=vocab_size,
        n_positions=256,
        n_embd=64,
        n_layer=2,
        n_head=2,
        bos_token_id=None,
        eos_token_id=None,
    )
    return GPT2LMHeadModel(config)


def main():
    print("=" * 70)
    print("SMOKE TEST: LoRA fine-tuning pipeline (offline, CPU, tiny model)")
    print("=" * 70)

    repo_root = os.path.join(os.path.dirname(__file__), "..")
    sample_data = os.path.join(repo_root, "examples", "sample_data.jsonl")
    lora_cfg_path = os.path.join(repo_root, "configs", "lora_config_smoke.yaml")

    tmp_dir = tempfile.mkdtemp(prefix="lora_smoke_")
    checkpoint_dir = os.path.join(tmp_dir, "checkpoint")

    try:
        print("\n[1/6] Training a tiny tokenizer from scratch on sample_data.jsonl ...")
        tokenizer = build_tiny_tokenizer(sample_data, tmp_dir)
        print(f"      vocab size: {tokenizer.vocab_size}")

        print("\n[2/6] Building a tiny randomly-initialized GPT-2-architecture model ...")
        model = build_tiny_model(vocab_size=tokenizer.vocab_size + 8)
        n_params = sum(p.numel() for p in model.parameters())
        print(f"      base model parameters: {n_params:,}")

        print("\n[3/6] Attaching LoRA adapters (configs/lora_config_smoke.yaml) ...")
        model = attach_lora(model, lora_cfg_path)

        print("\n[4/6] Loading + tokenizing examples/sample_data.jsonl ...")
        train_ds, eval_ds = load_document_qa_dataset(sample_data, val_split=0.34)
        collator = DataCollatorForCausalDocQA(tokenizer=tokenizer, max_length=128)
        loader = DataLoader(train_ds, batch_size=2, shuffle=True, collate_fn=collator)
        print(f"      train examples: {len(train_ds)} | eval examples: {len(eval_ds)}")

        print("\n[5/6] Running a few training steps (forward + backward + optimizer step) ...")
        optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-3)
        model.train()
        for step, batch in enumerate(loader):
            optimizer.zero_grad()
            outputs = model(**batch)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            print(f"      step {step} | loss {loss.item():.4f}")
            if step >= 2:
                break

        print(f"\n      saving LoRA adapter checkpoint to {checkpoint_dir} ...")
        model.save_pretrained(checkpoint_dir)
        tokenizer.save_pretrained(checkpoint_dir)

        print("\n[6/6] Reloading base model + adapter from disk and running generation ...")
        fresh_base = build_tiny_model(vocab_size=tokenizer.vocab_size + 8)
        loaded = PeftModel.from_pretrained(fresh_base, checkpoint_dir)
        loaded.eval()

        prompt = "### Document:\nLoRA freezes pretrained weights.\n\n### Question:\nWhat does LoRA freeze?\n\n### Answer:\n"
        inputs = tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            output_ids = loaded.generate(
                **inputs, max_new_tokens=10, do_sample=False, pad_token_id=tokenizer.pad_token_id
            )
        decoded = tokenizer.decode(output_ids[0])
        print(f"      generated (untrained tiny model, gibberish expected): {decoded!r}")

        print("\n" + "=" * 70)
        print("SMOKE TEST PASSED: data -> LoRA -> train -> save -> reload -> generate")
        print("all completed with no errors.")
        print("=" * 70)

    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
