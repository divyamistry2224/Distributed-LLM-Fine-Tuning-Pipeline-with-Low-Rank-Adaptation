"""
Data loading and preprocessing for document-understanding fine-tuning.

Expected input format: JSONL, one record per line:
    {"context": "<document text>", "question": "<question>", "answer": "<answer>"}

Records are converted into a single instruction-style prompt and tokenized
for causal language modeling, with loss masked over the prompt portion so
the model is only trained to predict the answer.

Truncation strategy: when context + question + answer exceed max_length, we
truncate the *document context* and never the answer or question. Naively
truncating the full formatted text (prompt + answer) can silently drop the
entire answer for long documents, leaving zero valid label tokens for that
example and producing a NaN loss with no clear error. Reserving space for the
fixed template, the question, and the answer up front — and only truncating
the context to whatever budget remains — avoids that failure mode.
"""

import logging
from dataclasses import dataclass

from datasets import load_dataset
from transformers import PreTrainedTokenizerBase

logger = logging.getLogger(__name__)

PROMPT_PREFIX = (
    "You are a helpful assistant that answers questions using only the "
    "provided document.\n\n"
    "### Document:\n"
)
PROMPT_TEMPLATE = PROMPT_PREFIX + "{context}\n\n### Question:\n{question}\n\n### Answer:\n"


def _suffix_for(question: str) -> str:
    return f"\n\n### Question:\n{question}\n\n### Answer:\n"


def build_token_ids(
    tokenizer: PreTrainedTokenizerBase,
    context: str,
    question: str,
    answer: str,
    max_length: int,
    min_answer_tokens: int = 8,
):
    """Tokenize one (context, question, answer) triple into (prompt_ids, full_ids),
    truncating the context as needed so the question and answer are always preserved
    in full (unless the question+answer alone already exceed max_length, in which
    case the answer is truncated as a last resort and a warning is logged).
    """
    prefix_ids = tokenizer(PROMPT_PREFIX, add_special_tokens=False)["input_ids"]
    suffix_ids = tokenizer(_suffix_for(question), add_special_tokens=False)["input_ids"]
    answer_ids = tokenizer(answer, add_special_tokens=False)["input_ids"]
    context_ids = tokenizer(context, add_special_tokens=False)["input_ids"]

    overhead = len(prefix_ids) + len(suffix_ids) + len(answer_ids)
    context_budget = max_length - overhead

    if context_budget < 0:
        # Question + answer alone don't fit. Truncate the answer as a last resort
        # so we still produce a valid (non-empty) training target, but flag it —
        # this usually means max_length is too small for this dataset.
        logger.warning(
            "Question+answer exceed max_length=%d even with an empty context "
            "(overhead=%d tokens); truncating the answer. Consider raising "
            "--max_length.",
            max_length,
            overhead,
        )
        allowed_answer = max(max_length - len(prefix_ids) - len(suffix_ids), min_answer_tokens)
        answer_ids = answer_ids[:allowed_answer]
        context_ids = []
    else:
        context_ids = context_ids[:context_budget]

    prompt_ids = prefix_ids + context_ids + suffix_ids
    full_ids = prompt_ids + answer_ids
    return prompt_ids, full_ids


def format_example(example: dict) -> dict:
    """Pass the raw fields through; tokenization happens in the collator so it
    can apply the context-aware truncation above (which needs a tokenizer)."""
    return {
        "context": example["context"],
        "question": example["question"],
        "answer": example["answer"],
    }


@dataclass
class DataCollatorForCausalDocQA:
    """Tokenizes (context, question, answer) triples and masks everything
    except the answer span in the labels, truncating long contexts rather
    than truncating the answer away."""

    tokenizer: PreTrainedTokenizerBase
    max_length: int = 2048

    def __call__(self, batch: list[dict]) -> dict:
        import torch

        input_ids_list, labels_list, attn_list = [], [], []
        pad_id = self.tokenizer.pad_token_id

        for example in batch:
            prompt_ids, full_ids = build_token_ids(
                self.tokenizer,
                example["context"],
                example["question"],
                example["answer"],
                self.max_length,
            )

            full_ids = full_ids[: self.max_length]
            pad_len = self.max_length - len(full_ids)
            attn = [1] * len(full_ids) + [0] * pad_len
            full_ids = full_ids + [pad_id] * pad_len

            labels = list(full_ids)
            prompt_len = min(len(prompt_ids), len(labels))
            for i in range(prompt_len):
                labels[i] = -100
            labels = [-100 if tok == pad_id else tok for tok in labels]

            if all(l == -100 for l in labels):
                # Should not happen given build_token_ids' guarantees, but fail loudly
                # rather than silently training on an all-masked (NaN-loss) example.
                raise ValueError(
                    "Produced an example with zero valid label tokens after "
                    "truncation; check max_length and the offending record: "
                    f"question={example['question']!r}"
                )

            input_ids_list.append(full_ids)
            labels_list.append(labels)
            attn_list.append(attn)

        return {
            "input_ids": torch.tensor(input_ids_list, dtype=torch.long),
            "attention_mask": torch.tensor(attn_list, dtype=torch.long),
            "labels": torch.tensor(labels_list, dtype=torch.long),
        }


def load_document_qa_dataset(train_file: str, eval_file: str | None = None, val_split: float = 0.05):
    """Load JSONL document-QA data.

    Args:
        train_file: path to a JSONL file with {"context", "question", "answer"} records.
        eval_file: optional separate JSONL file for evaluation. If omitted, a
            `val_split` fraction of `train_file` is held out.
        val_split: fraction of training data to hold out when no eval_file is given.
    """
    data_files = {"train": train_file}
    if eval_file:
        data_files["validation"] = eval_file

    raw = load_dataset("json", data_files=data_files)

    if "validation" not in raw:
        split = raw["train"].train_test_split(test_size=val_split, seed=42)
        raw = {"train": split["train"], "validation": split["test"]}
    else:
        raw = {"train": raw["train"], "validation": raw["validation"]}

    formatted = {
        # load_from_cache_file=False: this dataset is typically small and cheap to
        # reprocess, and datasets' on-disk map() cache can go stale if you edit
        # format_example/build_token_ids and rerun without clearing
        # ~/.cache/huggingface/datasets — disabling it avoids that footgun.
        split_name: ds.map(format_example, remove_columns=ds.column_names, load_from_cache_file=False)
        for split_name, ds in raw.items()
    }
    return formatted["train"], formatted["validation"]
