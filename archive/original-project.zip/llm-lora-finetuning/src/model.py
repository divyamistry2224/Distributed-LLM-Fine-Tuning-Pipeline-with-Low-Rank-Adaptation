"""
Loads a base causal LM (optionally in 4-bit precision) and attaches LoRA adapters.

Split into two composable steps so the pipeline can be exercised without a
CUDA GPU (e.g. in CI, or for local smoke-testing on CPU): `load_base_model`
handles fetching/quantizing the base model, and `attach_lora` wraps any
already-loaded model with LoRA adapters.
"""

import torch
import yaml
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer


def load_lora_config(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def bnb_4bit_available() -> bool:
    """4-bit quantization via bitsandbytes requires a CUDA GPU. Detect that here
    so callers can fall back to full/half precision on CPU-only machines."""
    if not torch.cuda.is_available():
        return False
    try:
        import bitsandbytes  # noqa: F401
        return True
    except ImportError:
        return False


def build_bnb_config(cfg: dict):
    from transformers import BitsAndBytesConfig

    quant_cfg = cfg["quantization"]
    compute_dtype = getattr(torch, quant_cfg["bnb_4bit_compute_dtype"])
    return BitsAndBytesConfig(
        load_in_4bit=quant_cfg["load_in_4bit"],
        bnb_4bit_quant_type=quant_cfg["bnb_4bit_quant_type"],
        bnb_4bit_use_double_quant=quant_cfg["bnb_4bit_use_double_quant"],
        bnb_4bit_compute_dtype=compute_dtype,
    )


def load_tokenizer(base_model: str):
    tokenizer = AutoTokenizer.from_pretrained(base_model, use_fast=True)
    if tokenizer.pad_token is None:
        # Most LLaMA-family tokenizers have no pad token by default.
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    return tokenizer


def load_base_model(base_model: str, lora_cfg_path: str, device_map="auto", force_no_quant: bool = False):
    """Load the base causal LM, in 4-bit if a CUDA GPU + bitsandbytes are available,
    otherwise falling back to full precision (CPU-friendly, used for smoke tests
    and machines without a GPU)."""
    cfg = load_lora_config(lora_cfg_path)
    use_4bit = cfg["quantization"]["load_in_4bit"] and not force_no_quant and bnb_4bit_available()

    if use_4bit:
        bnb_config = build_bnb_config(cfg)
        model = AutoModelForCausalLM.from_pretrained(
            base_model,
            quantization_config=bnb_config,
            device_map=device_map,
            torch_dtype=torch.bfloat16,
        )
        model = prepare_model_for_kbit_training(model)
    else:
        model = AutoModelForCausalLM.from_pretrained(
            base_model,
            device_map=device_map if torch.cuda.is_available() else None,
            torch_dtype=torch.float32,
        )
    return model, use_4bit


def attach_lora(model, lora_cfg_path: str):
    """Wrap an already-loaded causal LM with LoRA adapters, per the given config."""
    cfg = load_lora_config(lora_cfg_path)

    target_modules = list(cfg["target_modules"])
    if cfg.get("adapt_mlp"):
        target_modules += list(cfg["mlp_target_modules"])

    peft_config = LoraConfig(
        r=cfg["r"],
        lora_alpha=cfg["lora_alpha"],
        lora_dropout=cfg["lora_dropout"],
        target_modules=target_modules,
        bias=cfg["bias"],
        task_type=cfg["task_type"],
    )

    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()
    return model


def load_model_with_lora(base_model: str, lora_cfg_path: str, device_map="auto", force_no_quant: bool = False):
    """Convenience wrapper: load the base model and attach LoRA in one call."""
    model, used_4bit = load_base_model(base_model, lora_cfg_path, device_map, force_no_quant)
    model = attach_lora(model, lora_cfg_path)
    return model, used_4bit
