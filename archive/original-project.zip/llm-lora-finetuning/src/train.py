"""
Training entrypoint. Launch via `accelerate launch` (see scripts/run_train.sh),
which handles multi-GPU process spawning based on configs/accelerate_config.yaml.

Example:
    accelerate launch --config_file configs/accelerate_config.yaml src/train.py \\
        --base_model meta-llama/Llama-2-7b-hf \\
        --train_file examples/sample_data.jsonl \\
        --output_dir checkpoints/lora-doc-qa
"""

import argparse
import os

import torch
from accelerate import Accelerator
from torch.utils.data import DataLoader
from transformers import get_linear_schedule_with_warmup

from data import DataCollatorForCausalDocQA, load_document_qa_dataset
from model import load_model_with_lora, load_tokenizer
from utils import get_logger, set_seed

logger = get_logger()


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--base_model", type=str, default="meta-llama/Llama-2-7b-hf")
    p.add_argument("--train_file", type=str, required=True)
    p.add_argument("--eval_file", type=str, default=None)
    p.add_argument("--output_dir", type=str, default="checkpoints/lora-doc-qa")
    p.add_argument("--lora_config", type=str, default="configs/lora_config.yaml")
    p.add_argument("--num_train_epochs", type=int, default=3)
    p.add_argument("--per_device_train_batch_size", type=int, default=2)
    p.add_argument("--gradient_accumulation_steps", type=int, default=8)
    p.add_argument("--learning_rate", type=float, default=2e-4)
    p.add_argument("--max_length", type=int, default=2048)
    p.add_argument("--warmup_ratio", type=float, default=0.03)
    p.add_argument("--logging_steps", type=int, default=10)
    p.add_argument("--save_steps", type=int, default=200)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument(
        "--force_no_quant",
        action="store_true",
        help="Disable 4-bit quantization even if a GPU is available (mainly for debugging).",
    )
    return p.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)

    accelerator = Accelerator(gradient_accumulation_steps=args.gradient_accumulation_steps)

    tokenizer = load_tokenizer(args.base_model)
    model, used_4bit = load_model_with_lora(
        args.base_model, args.lora_config, force_no_quant=args.force_no_quant
    )
    if not used_4bit:
        logger.warning(
            "Running WITHOUT 4-bit quantization (no CUDA GPU + bitsandbytes detected, "
            "or --force_no_quant was set). This is fine for CPU smoke-testing on tiny "
            "models, but a 7B model needs a CUDA GPU with bitsandbytes for the memory "
            "savings described in the README."
        )

    train_ds, eval_ds = load_document_qa_dataset(args.train_file, args.eval_file)
    collator = DataCollatorForCausalDocQA(tokenizer=tokenizer, max_length=args.max_length)

    train_loader = DataLoader(
        train_ds,
        shuffle=True,
        batch_size=args.per_device_train_batch_size,
        collate_fn=collator,
    )
    eval_loader = DataLoader(
        eval_ds,
        shuffle=False,
        batch_size=args.per_device_train_batch_size,
        collate_fn=collator,
    )

    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad], lr=args.learning_rate
    )

    total_steps = (
        len(train_loader) // args.gradient_accumulation_steps * args.num_train_epochs
    )
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(total_steps * args.warmup_ratio),
        num_training_steps=total_steps,
    )

    model, optimizer, train_loader, eval_loader, scheduler = accelerator.prepare(
        model, optimizer, train_loader, eval_loader, scheduler
    )

    global_step = 0
    model.train()
    for epoch in range(args.num_train_epochs):
        running_loss = 0.0
        for step, batch in enumerate(train_loader):
            with accelerator.accumulate(model):
                outputs = model(**batch)
                loss = outputs.loss
                accelerator.backward(loss)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()

            running_loss += loss.detach().float()

            if accelerator.sync_gradients:
                global_step += 1
                if global_step % args.logging_steps == 0:
                    avg_loss = running_loss / (args.logging_steps * args.gradient_accumulation_steps)
                    logger.info(
                        f"epoch {epoch} | step {global_step} | loss {avg_loss:.4f} "
                        f"| lr {scheduler.get_last_lr()[0]:.2e}"
                    )
                    running_loss = 0.0

                if global_step % args.save_steps == 0:
                    _save_checkpoint(accelerator, model, tokenizer, args.output_dir, global_step)

        eval_loss = _evaluate(accelerator, model, eval_loader)
        logger.info(f"epoch {epoch} finished | eval_loss {eval_loss:.4f}")

    _save_checkpoint(accelerator, model, tokenizer, args.output_dir, "final")
    logger.info(f"Training complete. LoRA adapter saved to {args.output_dir}")


@torch.no_grad()
def _evaluate(accelerator, model, eval_loader):
    model.eval()
    losses = []
    for batch in eval_loader:
        outputs = model(**batch)
        losses.append(accelerator.gather(outputs.loss.repeat(batch["input_ids"].shape[0])))
    model.train()
    return torch.cat(losses).mean().item()


def _save_checkpoint(accelerator, model, tokenizer, output_dir, tag):
    if accelerator.is_main_process:
        save_path = os.path.join(output_dir, f"checkpoint-{tag}")
        os.makedirs(save_path, exist_ok=True)
        unwrapped = accelerator.unwrap_model(model)
        unwrapped.save_pretrained(save_path)  # saves LoRA adapter weights only
        tokenizer.save_pretrained(save_path)
        logger.info(f"Saved checkpoint to {save_path}")
    accelerator.wait_for_everyone()


if __name__ == "__main__":
    main()
