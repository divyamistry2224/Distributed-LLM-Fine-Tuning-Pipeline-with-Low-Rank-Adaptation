"""
Run generation with the base model + a trained LoRA adapter, or merge the
adapter into the base weights for standalone deployment.

Usage:
    python src/inference.py \\
        --base_model meta-llama/Llama-2-7b-hf \\
        --adapter_dir checkpoints/lora-doc-qa/checkpoint-final \\
        --context "..." --question "..."

    # Merge adapter into base weights and save a standalone model:
    python src/inference.py \\
        --base_model meta-llama/Llama-2-7b-hf \\
        --adapter_dir checkpoints/lora-doc-qa/checkpoint-final \\
        --merge_and_save merged_model/
"""

import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from data import PROMPT_TEMPLATE
from model import bnb_4bit_available


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--base_model", type=str, required=True)
    p.add_argument("--adapter_dir", type=str, required=True)
    p.add_argument("--context", type=str, default=None)
    p.add_argument("--question", type=str, default=None)
    p.add_argument("--max_new_tokens", type=int, default=256)
    p.add_argument("--merge_and_save", type=str, default=None,
                    help="If set, merge the adapter into base weights and save here instead of generating.")
    return p.parse_args()


def load_base_and_adapter(base_model: str, adapter_dir: str, for_merge: bool = False):
    if for_merge:
        # Load in full precision for a clean merge (no quantization artifacts).
        model = AutoModelForCausalLM.from_pretrained(base_model, torch_dtype=torch.float16)
    elif bnb_4bit_available():
        from transformers import BitsAndBytesConfig

        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
        )
        model = AutoModelForCausalLM.from_pretrained(
            base_model, quantization_config=bnb_config, device_map="auto"
        )
    else:
        # No CUDA GPU / bitsandbytes available: fall back to full precision.
        model = AutoModelForCausalLM.from_pretrained(
            base_model,
            device_map="auto" if torch.cuda.is_available() else None,
            torch_dtype=torch.float32,
        )

    tokenizer = AutoTokenizer.from_pretrained(base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = PeftModel.from_pretrained(model, adapter_dir)
    return model, tokenizer


def main():
    args = parse_args()

    if args.merge_and_save:
        model, tokenizer = load_base_and_adapter(args.base_model, args.adapter_dir, for_merge=True)
        merged = model.merge_and_unload()
        merged.save_pretrained(args.merge_and_save)
        tokenizer.save_pretrained(args.merge_and_save)
        print(f"Merged model saved to {args.merge_and_save}")
        return

    if not (args.context and args.question):
        raise ValueError("--context and --question are required unless using --merge_and_save")

    model, tokenizer = load_base_and_adapter(args.base_model, args.adapter_dir)
    model.eval()

    prompt = PROMPT_TEMPLATE.format(context=args.context, question=args.question)
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
            temperature=1.0,
            pad_token_id=tokenizer.pad_token_id,
        )

    generated = tokenizer.decode(output_ids[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    print(generated.strip())


if __name__ == "__main__":
    main()
