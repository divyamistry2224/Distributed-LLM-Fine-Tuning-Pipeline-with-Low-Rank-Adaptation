# Distributed LLM Fine-Tuning Pipeline with LoRA

A memory-efficient fine-tuning pipeline for 7B-parameter language models, built with **PyTorch**, **Hugging Face Transformers**, **PEFT (LoRA)**, **bitsandbytes (4-bit quantization)**, and **Hugging Face Accelerate** for multi-GPU training. The pipeline is designed for **document understanding** tasks (context-grounded question answering / instruction tuning over long-form text).

## Why this exists

Full fine-tuning of a 7B-parameter model requires >80GB of GPU memory for optimizer states alone. This pipeline uses:

- **QLoRA-style 4-bit quantization** (NF4, double quantization) via `bitsandbytes` to load the base model in ~5GB instead of ~28GB
- **LoRA (Low-Rank Adaptation)** via `peft` to train <1% of total parameters
- **Hugging Face Accelerate** to shard training across multiple GPUs (DDP / FSDP-ready) with a single config file
- **Gradient checkpointing** and **gradient accumulation** to keep per-GPU memory low while preserving effective batch size

The result: a 7B model can be fine-tuned on document-understanding data using consumer-grade or single-node multi-GPU hardware (e.g., 1–4x 24GB GPUs).

## Architecture

```
Raw documents (JSONL: context / question / answer)
        │
        ▼
 src/data.py  ──► tokenize + format as instruction prompts
        │
        ▼
 src/model.py ──► load base model in 4-bit (NF4) + attach LoRA adapters
        │
        ▼
 src/train.py ──► Accelerate-launched training loop (multi-GPU)
        │
        ▼
 checkpoints/ ──► LoRA adapter weights (a few MB, not the full model)
        │
        ▼
 src/inference.py ──► load base model + adapter, run generation
```

## Repository structure

```
llm-lora-finetuning/
├── README.md
├── requirements.txt
├── LICENSE
├── .gitignore
├── configs/
│   ├── lora_config.yaml         # LoRA hyperparameters for the real (LLaMA-family) model
│   ├── lora_config_smoke.yaml   # LoRA config for the offline CPU smoke test (GPT-2 arch)
│   └── accelerate_config.yaml   # multi-GPU / mixed-precision launch config
├── src/
│   ├── data.py                  # dataset loading, context-aware truncation, tokenization
│   ├── model.py                 # base model loading (4-bit or CPU fallback) + LoRA attach
│   ├── train.py                 # training entrypoint
│   ├── inference.py             # inference / adapter merging
│   └── utils.py                 # logging, seeding, metrics helpers
├── scripts/
│   ├── run_train.sh             # launches training via `accelerate launch`
│   ├── run_inference.sh
│   └── smoke_test.py            # offline end-to-end pipeline test (see "Verified" below)
├── examples/
│   └── sample_data.jsonl        # tiny example dataset in the expected format
└── .github/workflows/ci.yml     # CI: lint + runs the smoke test on every push
```

## Quickstart

### 1. Install dependencies

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure Accelerate for your hardware

```bash
accelerate config   # interactive, or edit configs/accelerate_config.yaml directly
```

### 3. Prepare data

Data is expected as JSONL, one record per line:

```json
{"context": "...", "question": "...", "answer": "..."}
```

See `examples/sample_data.jsonl` for the format. Point `--train_file` / `--eval_file` at your own dataset (any long-form document QA or instruction-tuning corpus works — SQuAD-style, DocVQA text pairs, internal support-ticket corpora, etc.).

### 4. Launch training

```bash
bash scripts/run_train.sh
```

This runs:

```bash
accelerate launch --config_file configs/accelerate_config.yaml src/train.py \
    --base_model meta-llama/Llama-2-7b-hf \
    --train_file examples/sample_data.jsonl \
    --output_dir checkpoints/lora-doc-qa \
    --lora_config configs/lora_config.yaml \
    --num_train_epochs 3 \
    --per_device_train_batch_size 2 \
    --gradient_accumulation_steps 8 \
    --learning_rate 2e-4
```

Only the LoRA adapter weights (a few MB) are saved to `checkpoints/`, not the full base model.

### 5. Run inference

```bash
bash scripts/run_inference.sh \
    --base_model meta-llama/Llama-2-7b-hf \
    --adapter_dir checkpoints/lora-doc-qa \
    --context "..." \
    --question "..."
```

## Verified end-to-end (offline, no GPU needed)

Running an actual 7B model needs a real GPU and a Hugging Face Hub download,
neither of which is available in every environment. So this repo ships
`scripts/smoke_test.py`, which exercises the **entire pipeline** —
tokenization, LoRA attachment, the training loop, checkpoint saving, reload,
and generation — end-to-end, offline, on CPU, in a few seconds, using a tiny
randomly-initialized model built from scratch instead of downloading a real
one:

```bash
python scripts/smoke_test.py
```

This, along with `src/train.py` and `src/inference.py` themselves (not just
the smoke test), has been run and passes cleanly with no exceptions:

- `scripts/smoke_test.py` — full pipeline (tokenizer → LoRA → train → save → reload → generate)
- `src/train.py`, invoked both directly and via `accelerate launch` (the same way `scripts/run_train.sh` calls it), against a small local model
- `src/inference.py`, both the generation path and `--merge_and_save`

`configs/lora_config_smoke.yaml` is a GPT-2-compatible LoRA config used only
by the smoke test (GPT-2's fused `c_attn` module differs from LLaMA's separate
`q_proj`/`k_proj`/`v_proj`) — real training runs use `configs/lora_config.yaml`
as shown above.

**What this does *not* verify**: actual 4-bit quantization (`bitsandbytes`
requires a CUDA GPU — the code auto-detects its absence and falls back to full
precision, which is what the smoke test exercises instead), true multi-GPU
sharding, or output quality on a real pretrained model. Those need real GPU
hardware and a Hugging Face Hub download to test. `.github/workflows/ci.yml`
runs the smoke test on every push so regressions in the pipeline logic itself
are still caught automatically.

**Two real bugs were caught and fixed via this testing**, not left for a
future user to discover: `transformers>=5.0` combined with `tokenizers>=0.21`
breaks fast-tokenizer construction from a raw `tokenizers` backend (pinned in
`requirements.txt`), and naive prompt truncation could silently drop the
answer entirely for long documents, producing a NaN loss with no clear error
(`src/data.py` now truncates the document context instead, and raises a clear
error if that's ever still not enough).

## Key implementation details

| Component | Choice | Reason |
|---|---|---|
| Quantization | 4-bit NF4, double quantization (`bitsandbytes`) | ~4x memory reduction vs. fp16 with minimal quality loss |
| Adapter method | LoRA, rank 16, alpha 32, target `q_proj`/`k_proj`/`v_proj`/`o_proj` | Trains <1% of parameters; adapters are portable and mergeable |
| Multi-GPU | Hugging Face Accelerate | Single config file switches between DDP, FSDP, and single-GPU without code changes |
| Memory | Gradient checkpointing + gradient accumulation | Keeps activation memory bounded while preserving effective batch size |
| Precision | bf16 compute dtype during quantized matmuls | Numerically stable on Ampere+ GPUs |

## Results (example run)

> Replace this section with your own numbers once you've run training on your dataset/hardware.

| Metric | Base model (zero-shot) | After LoRA fine-tuning |
|---|---|---|
| Exact match | — | — |
| F1 | — | — |
| Training time (4x A10G, 3 epochs) | — | — |
| Peak GPU memory / device | — | — |

## Requirements

- Python 3.10+
- CUDA-capable GPU(s) with ≥16GB VRAM recommended per device
- See `requirements.txt` for pinned package versions

## License

MIT — see `LICENSE`.
